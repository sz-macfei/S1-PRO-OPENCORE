#<cldoc:USB Support>

&#8291;

VoodooI2C has experimental support for USB multitouch devices such as touchscreens and trackpads. There are no instructions for these kinds of devices, simply inject `VoodooI2C.kext` and the satellite `VoodooI2CHID.kext` usint Clover and you should be good to go!